<template>
  <b-container>
    <div class="page-header">
      <h2 class="text-center">Game Manager</h2>
      <hr />
    </div>
    <b-row>
      <b-col>
        <b-table striped hover :items="games" :fields="fields">
          <template slot="Tipo" slot-scope="data">{{getGameType(data.item.Tipo)}}</template>
          <template slot="Piattaforma" slot-scope="data">{{getPiattaforma(data.item.Piattaforma)}}</template>
          <template slot=" " slot-scope="data">
            <b-btn size="sm" variant="warning">X</b-btn>&nbsp;
            <b-btn size="sm" variant="secondary">M</b-btn>
          </template>
        </b-table>
      </b-col>
    </b-row>
  </b-container>

</template>

<script>
import { gamesRef } from './firebase'
import { GameTypeEnum, PiattaformaEnum } from './models/game'



export default {
  firebase: {
    games: gamesRef.orderByChild('Titolo')
  },

  data() {
    return {
      gameTypes: GameTypeEnum.properties,
      gamePlatforms: PiattaformaEnum.properties,
      fields: ['Titolo', 'SoftwareHouse', 'Tipo', 'Piattaforma', ' ']
    }
  },
  
  methods: {
    getPiattaforma(value) {
      return this.gamePlatforms[value].text;
    },
    getGameType(value) {
      return this.gameTypes[value].text;
    }
  }


}


</script>

  <style lang="scss">
  .page-header {
    background-color: #226622;
    color: #ffffff;
  }
  .page-header h2 {
    padding-top: 8px;
  }

</style>
