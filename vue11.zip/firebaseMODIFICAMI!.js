import Firebase from 'firebase/app'
import 'firebase/database'

const app = Firebase.initializeApp({
  apiKey: "QUI I VOSTRI DATI!!",
  authDomain: "QUI I VOSTRI DATI!!",
  databaseURL: "QUI I VOSTRI DATI!!",
  projectId: "QUI I VOSTRI DATI!!",
  storageBucket: "QUI I VOSTRI DATI!!",
  messagingSenderId: "QUI I VOSTRI DATI!!"
})  // configurazione per l’accesso al cloud
export const db = app.database() // recuperiamo il database
export const gamesRef = db.ref('Games') // recup rif alla collect.
