<template>
  <b-container>
    <div class="page-header">
      <h2 class="text-center">Game Manager</h2>
      <hr />
    </div>
    <b-row>
      <b-col lg="4">
        <b-form v-on:submit.prevent="onSubmit()">
          
          <b-form-group label="Titolo" label-for="titolo">
            <b-form-input type="text" id="titolo" name="titolo" v-model="newGame.Titolo" v-on:change="onChange()" />
          </b-form-group>
          
          <b-form-group label="SoftwareHouse" label-for="softwarehouse">
            <b-form-input type="text" id="softwarehouse" name="softwarehouse" v-model="newGame.SoftwareHouse" v-on:change="onChange()" />
          </b-form-group>
          
          <b-form-group label="Tipo" label-for="tipo">
            <b-form-select id="tipo" name="tipo" v-model="newGame.Tipo" :options="gameTypes">
            </b-form-select>
          </b-form-group>
          
          <b-form-group label="Piattaforma" label-for="piattaforma">
            <b-form-select id="piattaforma" name="piattaforma" v-model="newGame.Piattaforma" :options="gamePlatforms">
          </b-form-select>
          </b-form-group>
          
          <b-btn type="submit" variant="primary" :disabled="submitIsDisabled">Aggiungi</b-btn>
         
         </b-form>
         <br />

      </b-col>

      <b-col lg="8">
        <b-table striped hover :items="games" :fields="fields">
          <template slot="Tipo" slot-scope="data">{{getGameType(data.item.Tipo)}}</template>
          <template slot="Piattaforma" slot-scope="data">{{getPiattaforma(data.item.Piattaforma)}}</template>
          
          <!-- eslint-disable-next-line -->
          <template slot=" " slot-scope="data">
            <b-btn size="sm" variant="warning">X</b-btn>&nbsp;
            <b-btn size="sm" variant="secondary">M</b-btn>
          </template>
        </b-table>
      </b-col>
    </b-row>
  </b-container>

</template>

<script>
import { gamesRef } from './firebase'
import { GameTypeEnum, PiattaformaEnum } from './models/game'



export default {
  firebase: {
    games: gamesRef.orderByChild('Titolo')
  },

  data() {
    return {
      gameTypes: GameTypeEnum.properties,
      gamePlatforms: PiattaformaEnum.properties,
      fields: ['Titolo', 'SoftwareHouse', 'Tipo', 'Piattaforma', ' '],
      newGame: {
        Titolo: '',
        SoftwareHouse: '',
        Tipo: GameTypeEnum.FPS,
        Piattaforma: PiattaformaEnum.PC
      },
      submitIsDisabled: true
    }
  },
  
  methods: {
    getPiattaforma(value) {
      return this.gamePlatforms[value].text;
    },
    getGameType(value) {
      return this.gameTypes[value].text;
    },

    onSubmit(){
      gamesRef.push(this.newGame);
      this.newGame.Titolo = '';
      this.newGame.SoftwareHouse = '';
      this.submitIsDisabled = true;
    },
    
    onChange(){
      this.submitIsDisabled = this.newGame.Titolo === '' || this.newGame.SoftwareHouse === '';
    }

  }


}


</script>

  <style lang="scss">
  .page-header {
    background-color: #226622;
    color: #ffffff;
  }
  .page-header h2 {
    padding-top: 8px;
  }

</style>
