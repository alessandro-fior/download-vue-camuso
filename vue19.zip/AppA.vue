
<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    
    <error-check>
      <non-usabile></non-usabile>
    </error-check>
  
    
    <non-usabile></non-usabile>
  </div>
</template>

<script>
import NonUsabile from './components/NonUsabile.vue'
import ErrorCheck from './components/ErrorCheck.vue'


export default {
  name: 'app',
  components: {
    NonUsabile, ErrorCheck
  }
}
</script>
