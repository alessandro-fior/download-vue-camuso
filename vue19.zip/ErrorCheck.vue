<template>
    <div>
        <template v-if="error">
            <p>Qualcosa è andato storto!</p>
        </template>
        <template v-else>
            <slot></slot>
        </template>
    </div>
</template>

<script>
export default {
    name: "ErrorCheck",
    data() {
        return {
            error: false
        }
    }    
}
</script>
