<template>
    <div>
        <template v-if="error">
            <p>Errore!</p>
        </template>
        <template v-else>
            <p>Phone: {{mioValore}}</p>
        </template>
    </div>
</template>

<script>
export default {
    name: "NonUsabile",
    data() {
        return {
            valore: "5555-555-55",
            error: false
        }
    },
    computed: {
        mioValore() {  return this.valore.replace(/-/g, ""); }
    }
}
</script>
