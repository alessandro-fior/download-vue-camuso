<template>
    <div>
        <template v-if="error">
            <p>Dato non disponibile</p>
        </template>
        <template v-else>
            <slot></slot>
        </template>
    </div>
</template>

<script>
export default {
    data() {
        return {
            error: false
        }
    },
    // questa funzione intercetta errori dei usati
    // non quelli di questo componente
    errorCaptured(err, comp, msg) {
        alert("AppErrorCheck");
        this.error = true; 
        return true; // false: non propagare - true: propaga verso l'alto
    }
}
</script>