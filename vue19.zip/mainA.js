import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false;

// Vue.config.errorHandler = function(err, vm, msg){
//   alert(err + "#" + vm + "#" + msg);
// };

new Vue({
  render: h => h(App),
  beforeCreate() { 
    alert("beforeCreate");
  },
   // eseguito dopo la creazione dell'istanza,
  // e dopo l'avvio dell'osservazione e degli eventi
  created() {
    alert("created");
  },
  // eseguito prima del rendering
  beforeMount() {
    alert("beforeMount");
  },
  // eseguito dopo il rendering
  mounted() {
    alert("mounted");
  },
  // eseguito prima dell'aggiornamento del DOM
  beforeUpdate() {
    alert("beforeUpdate");
  },
   // eseguito dopo dell'aggiornamento del DOM
  updated() {
    alert("updated");
  },
  // eseguito nel caso il componente sia sotto il controllo del keep-alive
  activated() {
    alert("activated");
  },
  // eseguito nel caso il componente sia sotto il controllo del keep-alive
  // ed è stato disattivato
  deactivated() {
    alert("deactivated");
  },
  // eseguito prima che Vue distrugga il componente dopo la rimozione dal DOM
  beforeDestroy() {
    alert("beforeDestroy");
  },
    // eseguito dopo che Vue ha distrutto il componente dopo la rimozione dal DOM
  destroyed() {
    alert("destroyed");
  }
  

}).$mount('#app')
