<template>
    <div>
        <p>Telefono: {{TelToNumber}}</p>
    </div>
</template>

<script>
export default {
    data() {
        return {
            error: false,
            //telefono: "555-555-555",
            telefono: null
        }
    },
    computed: {
        TelToNumber() {
            return this.telefono.replace(/-/g, "");
        }
    }
} 
</script>