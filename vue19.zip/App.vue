<template>
  <div id="app">
    <app-errorcheck>
      <app-nonusabile></app-nonusabile>
    </app-errorcheck>
  </div>
</template>

<script>
import AppErrorcheck from "./components/AppErrorcheck"
import AppNonusabile from "./components/AppNonusabile"

export default {
  name: 'app',
  components: {
    AppErrorcheck, AppNonusabile
  },
  data() {
    return {
    }    
  },
  // questa funzione viene eseguita solo se AppErrorcheck permette la propagazione
  errorCaptured(err, comp, msg) {
      alert("App.vue  -  Errore intercettato");
      return false; // false: non propagare - true: propaga verso l'alto
    }
}
</script>
