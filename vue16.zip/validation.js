import Vue from 'vue'

Vue.component('my-component', {
  props: {
    // Controllo base del tipo (null vale per ogni tipo)
    propA: Number,

    // Possibilità multipla
    propB: [String, Number],

    // di tipo string obbligatorio
    propC: {
      type: String,
      required: true
    },

    // numerico con un valore di default
    propD: {
      type: Number,
      default: 100
    },

    // oggetto con valori di default
    propE: {
      type: Object,
      // oggetti o array di default devono essere un valore di ritorno di una funzione
      default: function () {
        return { message: 'hello' }
      }
    },

    // Validazione personalizzata
    propF: {
      validator: function (value) {
        // il valore deve essere uno delle seguenti stringhe
        return ['success', 'warning', 'danger'].indexOf(value) !== -1
      }
    }
  }
})

// String
// Number
// Boolean
// Array
// Object
// Date
// Function
// Symbol


// function Utente (username, email) {
//   this.username = username
//   this.email = email
// }

// props: {
// 	userAccess: Utente
// }
