
<template>
    <div>
        <button @click="count++; $emit('add-click', count);">Counter: {{count}}</button>
    </div>
</template>

<script>
export default {
    data() {
        return {
            count: 0
        }
    }
}
</script>
