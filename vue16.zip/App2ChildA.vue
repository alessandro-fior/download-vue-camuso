<template>
    <div>
        <!-- <p>{{app2Utente.username}}</p>
        <p>{{app2Utente.email}}</p>
        <p>{{titolo}} {{id}}</p> -->

        <!-- <p>{{vettore[0]}}, {{vettore[1]}}</p> -->

        <p>{{titolo}} {{id}}</p>

    </div>
</template>

<script>
export default {
     props: 
      // ['app2Utente']
      {
        // id: Number,
        // titolo: String,
        // app2Utente: Object,
        // vettore: Array,
        id: Number,
        titolo: String
        
      }

}
</script>
