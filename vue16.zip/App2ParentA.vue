<template>
    <div>
        <h2>Parent</h2>
        <!-- <app2-child :utente="account"></app2-child>
        <app2-child :utente="{username: 'mrossi', email: 'mario.rossi@email.it'}"></app2-child> -->

       <!-- <app2-child :app2-utente="account" :id="id" :titolo="titolo"  ></app2-child> -->
       <!-- <app2-child :app2-utente="{username: 'tizio', email: 'tizio@email.it'}"></app2-child>
       <app2-child :vettore="['caio', 'caio@email.it']"></app2-child> -->
       <app2-child v-bind="obj"></app2-child>
    </div>
</template>

<script>
import App2Child from './App2Child'

export default {
    data() {
        return {
            // account: {
            //     username: "mrossi",
            //     email: "mario.rossi@email.it"
            // },
            // id: 777,
            // titolo: "CIAO",
            
            obj: {
                  id: 5,
                  titolo: "hello world",
            }

        }
    },

    components: {
        App2Child
    }
}
</script>

