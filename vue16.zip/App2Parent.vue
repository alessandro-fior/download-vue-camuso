<template>
    <div>
        <h2>Click totali {{totalClick}}</h2>
        <h4>Questo bottone è stato cliccato {{currentClick}} volte</h4>
        <app2-child v-on:add-click="totalClick++; currentClick=$event;"></app2-child>
        <app2-child v-on:add-click="totalClick++; currentClick=$event;"></app2-child>
        <app2-child v-on:add-click="totalClick++; currentClick=$event;"></app2-child>

    </div>
</template>

<script>
import App2Child from './App2Child'

export default {
    data() {
        return {
            totalClick: 0,
            currentClick: 0
        }
    },
    components: {
        App2Child
    }
}
</script>
