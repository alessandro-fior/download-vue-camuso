<template>
  <div id="app">
    <button v-for="tab in tabs" v-bind:key="tab" v-on:click="currentTab = tab">
      {{ tab }}
    </button>
    <component v-bind:is="currentTabComponent"></component>
  </div>
</template>

<script>
import TabArchive from "./components/TabArchive"
import TabHome from "./components/TabHome"
import TabPosts from "./components/TabPosts"

export default {
  name: 'app',
  components: {
    TabArchive, TabHome, TabPosts
  },
  data(){
    return {
      currentTab: 'Home',
      tabs: ['Home', 'Posts', 'Archive']
    }
  },
  computed: {
    currentTabComponent: function () {
      return 'tab-' + this.currentTab.toLowerCase()
    }
  }
}
</script>