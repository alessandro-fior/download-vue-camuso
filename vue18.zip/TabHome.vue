<template>
    <div>Home component</div>
</template>
<script>
export default { }
</script>