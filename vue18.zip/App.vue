<template>
  <div id="app">
    <input type="checkbox" v-model="isChecked" />
    <keep-alive>
      <component v-bind:is="selectedComponent"></component>
    </keep-alive>
  </div>
</template>

<script>
import AppAuthors from './components/AppAuthors.vue'
import AppPosts from './components/AppPosts.vue'

export default {
  name: 'app',
  components: {
    AppAuthors,
    AppPosts
  },
  data() {
    return {
      isChecked: false
    }
  },
  computed: {
    selectedComponent() {
      return this.isChecked ? "AppAuthors" : "AppPosts";
    }
  }
}
</script>