<template>
  <div id="app">
    <button v-for="tab in tabs" v-bind:key="tab.name" v-on:click="currentTab = tab">
     {{ tab.name }}
    </button>
    <component v-bind:is="currentTab.component"></component>
  </div>
</template>

<script>
import TabArchive from "./components/TabArchive"
import TabHome from "./components/TabHome"
import TabPosts from "./components/TabPosts"

export default {
  name: 'app',
  data(){
    return {    
      tabs: [
        { name: 'Home', component: TabHome },
        { name: 'Posts', component: TabPosts },
        { name: 'Archive', component: TabArchive }
      ],
      currentTab: {}
    }
  },
  created() {
    this.currentTab = this.tabs[0];
  }
}
</script>