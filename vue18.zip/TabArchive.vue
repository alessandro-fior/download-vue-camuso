<template>
    <div>Archive component</div>
</template>
<script>
export default { }
</script>