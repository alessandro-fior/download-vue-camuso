<template>
    <div>Posts component</div>
</template>
<script>
export default { }
</script>