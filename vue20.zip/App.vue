<template>
  <div id="app">
     <h2>Messaggio: {{msg | nospazi('#') | upper}}</h2>
  </div>
</template>

<script>

export default {
  name: 'app',
   data() {
    return {
      msg: 'Testo di prova'
    }
   },
  //  methods: {
  //     upper(value) {
  //     return value.toUpperCase();
  //  },
  //     nospazi(value) {
  //       return value.replace(/ /g, "_");
  //  }
  //  filters: {
  //     upper(value) {
  //     return value.toUpperCase();
  //  },
  //     nospazi(value, carattere) {
  //       return value.replace(/ /g, carattere);
  //  }
   
  //  }
}

</script>