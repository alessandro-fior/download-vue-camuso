import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

Vue.filter(
  'upper', 
  function (value) {
  return value.toUpperCase();
});

Vue.filter(
  'nospazi', 
  function (value, carattere) {
  return value.replace(/ /g, carattere);
});


new Vue({
  render: h => h(App),
}).$mount('#app')
