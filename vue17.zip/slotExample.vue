
<template>
	<div class="container">
		<header><slot name="slot1"> Titolo di default </slot></header>

		<main><slot> </slot></main>

		<footer><slot name="slot2"></slot></footer>
	</div>
</template>

<script>
export default {
  data() {
        return {
            prop_del_child: "SLOT N. 2"
        }
    }
}
</script>


    



