<template>
  <div id="app">
    <todo-list v-bind:todos="todos">

      <!-- Diamo un nome allo scope (contesto) da usare nel template "slotContexts" -->
      <template slot-scope="slotContext">
        <!-- In questo caso il context contiene solo l'oggetto "todo" -->
        <!-- creato dal v-for del componente e che andremo ad usare -->
        <span v-if="slotContext.todo.isComplete">✓✓✓</span>
        {{ slotContext.todo.text }}
      </template>

    </todo-list>
  </div>
</template>

<script>
import TodoList from "./components/TodoList"

export default {
  name: 'app',
  components: {
    TodoList
  },
  data() {
    return {
      todos: [
        { id: 1, text: "Comprare scarpe", isComplete: false},
        { id: 2, text: "Fare la spesa", isComplete: true},
        { id: 3, text: "Biglietti cinema", isComplete: false},
      ]
    }
  }
}
</script>
