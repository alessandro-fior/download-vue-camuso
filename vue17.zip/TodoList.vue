<template>
    <div>
        <!-- versione classica -->
        <ul>
            <li v-for="todo in todos" :key="todo.id">
                {{ todo.text }}
                <span v-if="todo.isComplete">✓</span>
            </li>
        </ul>
        <hr />

       <!-- versione che fa uso del template fornito dal parent -->
        <ul>
            <!-- Il v-for crea l'oggetto "todo" -->
            <li v-for="todo in todos" :key="todo.id">
                <!-- Oltre a richiamare lo slot, gli forniamo l'item iterato -->
                <slot :todo="todo">
                  <!-- Nal caso il parent non dovesse fornire un template viene usato il seguente -->
                  {{todo.text}}
                </slot>
            </li>
        </ul>        

    </div>
</template>

<script>
export default {
    props: [ "todos" ]
}
</script>
