<template>
  <div>
    <slot-example v-bind:colori="colori"> 
<!-- 
      <template slot="slot1">
        <h2>Contenuto Slot N.1</h2> 
      </template>

      <p>Contenuto classico</p>
      
      <template slot="slot2">
        <h4>Contenuto Slot N.2</h4>        
      </template> 

      <h2 slot="slot1">Contenuto Slot N.1</h2> 
      <p>Contenuto classico</p>
      <h4 slot="slot2">Contenuto Slot N.2</h4>         -->

      <template slot="slot1">
        <h2>Contenuto {{prop_del_parent}} </h2>
      </template>

      <p>Contenuto classico</p>
      
      <template slot="slot2">
        <h4>Contenuto {{prop_del_child}}</h4>
        
      </template>    
    </slot-example>
  </div>
</template>

<script>
import slotExample from './components/slotExample.vue'

export default {
    data() {
        return {
            prop_del_parent: "SLOT N. 1"
        }
    },

    components: {
    slotExample
  }
}
</script>

